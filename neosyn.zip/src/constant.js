export const services = {
    serviceType:[
        {title:"Web Development",
        path:"/services/webDevelopment"},
        {title:"UI/UX Design",
        path:"/services/uiUxDe"},
        {title:"Digital Marketing",
        path:"/services/digitalMarketing"},
        {title:"Product Design",
        path:"/services/productDesign"},
        {title:"Mobile Solutions",
        path:"/services/mobileSolutions"},
        {title:"App Development",
        path:"/services/appDevelopment"},
        {title:"Email Marketing",
        path:"/services/emailMarketing"},
        

        
    ]

}